// Global variables
let currentUserId; // This should be set from your platform's session
let currentView = 'list'; // 'list', 'detail', 'compose'
let currentFolder = 'inbox';
let darkMode = false;

document.addEventListener('DOMContentLoaded', function() {
    // Initialize the app
    initMessenger();
    
    // Event listeners
    document.querySelector('.compose-btn').addEventListener('click', showComposeView);
    document.querySelector('.back-btn').addEventListener('click', showMessageListView);
    document.querySelector('.close-btn').addEventListener('click', showMessageListView);
    document.querySelector('.reply-btn').addEventListener('click', replyToMessage);
    document.querySelector('.send-btn').addEventListener('click', sendMessage);
    document.querySelector('.discard-btn').addEventListener('click', showMessageListView);
    document.getElementById('theme-toggle').addEventListener('click', toggleDarkMode);
    
    // User search functionality
    document.getElementById('user-search').addEventListener('input', searchUsers);
    document.getElementById('recipient').addEventListener('input', searchUsersForCompose);
    
    // Folder navigation
    document.querySelectorAll('.folder').forEach(folder => {
        folder.addEventListener('click', function() {
            document.querySelectorAll('.folder').forEach(f => f.classList.remove('active'));
            this.classList.add('active');
            currentFolder = this.dataset.folder;
            document.getElementById('folder-title').textContent = this.textContent.trim();
            loadMessages(currentFolder);
            showMessageListView();
        });
    });
});

function initMessenger() {
    // Check for saved theme preference
    const savedMode = localStorage.getItem('darkMode');
    if (savedMode === 'true') {
        darkMode = true;
        document.body.classList.add('dark-mode');
        document.getElementById('theme-toggle').innerHTML = '<i class="fas fa-sun"></i>';
    }
    
    // Load initial data
    loadMessages(currentFolder);
    
    // Set current user (this should come from your platform)
    // currentUserId = 1; // Example - replace with actual user ID from your platform
}

function toggleDarkMode() {
    darkMode = !darkMode;
    document.body.classList.toggle('dark-mode');
    
    // Save preference
    localStorage.setItem('darkMode', darkMode);
    
    // Update icon
    const icon = darkMode ? '<i class="fas fa-sun"></i>' : '<i class="fas fa-moon"></i>';
    document.getElementById('theme-toggle').innerHTML = icon;
}

function loadMessages(folder) {
    // Show loading state
    const messageList = document.querySelector('.message-list');
    messageList.innerHTML = '<div class="loading">Loading messages...</div>';
    
    // Fetch messages from server
    fetch(`api/get_messages.php?folder=${folder}&user_id=${currentUserId}`)
        .then(response => response.json())
        .then(messages => {
            messageList.innerHTML = '';
            
            if (messages.length === 0) {
                messageList.innerHTML = '<div class="empty">No messages found</div>';
                return;
            }
            
            messages.forEach(message => {
                const messageItem = document.createElement('div');
                messageItem.className = `message-item ${message.is_read ? '' : 'unread'}`;
                messageItem.dataset.id = message.id;
                
                const fromTo = folder === 'inbox' ? 
                    `<div class="message-sender">${message.sender}</div>` : 
                    `<div class="message-sender">To: ${message.recipient}</div>`;
                
                // Create avatar with initials
                const name = folder === 'inbox' ? message.sender : message.recipient;
                const initials = getInitials(name);
                
                messageItem.innerHTML = `
                    <div class="avatar">${initials}</div>
                    <div class="message-content">
                        ${fromTo}
                        <span class="message-date">${message.date}</span>
                        <div class="message-preview">
                            <strong>${message.subject}</strong> - ${message.preview}
                        </div>
                    </div>
                `;
                
                messageItem.addEventListener('click', () => viewMessage(message.id));
                messageList.appendChild(messageItem);
            });
        })
        .catch(error => {
            messageList.innerHTML = '<div class="error">Failed to load messages</div>';
            console.error('Error loading messages:', error);
        });
}

function getInitials(name) {
    return name.split(' ').map(part => part[0]).join('').toUpperCase();
}

function viewMessage(id) {
    // Show loading state
    const messageDetailView = document.getElementById('message-detail-view');
    messageDetailView.innerHTML = '<div class="loading">Loading message...</div>';
    messageDetailView.style.display = 'block';
    
    // Hide other views
    document.getElementById('message-list-view').style.display = 'none';
    document.getElementById('compose-view').style.display = 'none';
    currentView = 'detail';
    
    // Fetch message details
    fetch(`api/get_message.php?id=${id}&user_id=${currentUserId}`)
        .then(response => response.json())
        .then(message => {
            document.getElementById('message-subject').textContent = message.subject;
            document.getElementById('message-from').textContent = `From: ${message.sender}`;
            document.getElementById('message-date').textContent = message.date;
            document.getElementById('message-body').textContent = message.body;
            
            // Mark as read if it's an incoming message
            if (currentFolder === 'inbox' && !message.is_read) {
                fetch(`api/mark_as_read.php?id=${id}`);
                // Update the message item in the list
                const messageItem = document.querySelector(`.message-item[data-id="${id}"]`);
                if (messageItem) {
                    messageItem.classList.remove('unread');
                }
            }
        })
        .catch(error => {
            messageDetailView.innerHTML = '<div class="error">Failed to load message</div>';
            console.error('Error loading message:', error);
        });
}

function showComposeView() {
    document.getElementById('message-list-view').style.display = 'none';
    document.getElementById('message-detail-view').style.display = 'none';
    document.getElementById('compose-view').style.display = 'block';
    currentView = 'compose';
    
    // Clear form
    document.getElementById('recipient').value = '';
    document.getElementById('subject').value = '';
    document.getElementById('message-text').value = '';
    document.getElementById('search-results').innerHTML = '';
    document.getElementById('search-results').style.display = 'none';
    
    // Focus on recipient field
    document.getElementById('recipient').focus();
}

function showMessageListView() {
    document.getElementById('message-list-view').style.display = 'block';
    document.getElementById('message-detail-view').style.display = 'none';
    document.getElementById('compose-view').style.display = 'none';
    currentView = 'list';
}

function replyToMessage() {
    if (currentView !== 'detail') return;
    
    const recipient = document.getElementById('message-from').textContent.replace('From: ', '');
    const subject = document.getElementById('message-subject').textContent;
    
    document.getElementById('recipient').value = recipient;
    document.getElementById('subject').value = subject.startsWith('Re:') ? subject : `Re: ${subject}`;
    
    showComposeView();
    document.getElementById('message-text').focus();
}

function sendMessage() {
    const recipient = document.getElementById('recipient').value.trim();
    const subject = document.getElementById('subject').value.trim();
    const body = document.getElementById('message-text').value.trim();
    
    if (!recipient || !body) {
        showAlert('Recipient and message body are required');
        return;
    }
    
    // Show sending state
    const sendBtn = document.querySelector('.send-btn');
    const btnText = sendBtn.querySelector('.btn-text');
    const originalText = btnText.textContent;
    btnText.textContent = 'Sending...';
    sendBtn.disabled = true;
    
    fetch('api/send_message.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            sender_id: currentUserId,
            recipient,
            subject,
            body
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showAlert('Message sent successfully', 'success');
            showMessageListView();
            loadMessages('sent');
        } else {
            showAlert('Error: ' + (data.error || 'Failed to send message'), 'error');
        }
    })
    .catch(error => {
        showAlert('Failed to send message', 'error');
        console.error('Error sending message:', error);
    })
    .finally(() => {
        btnText.textContent = originalText;
        sendBtn.disabled = false;
    });
}

function searchUsers() {
    const query = document.getElementById('user-search').value.trim();
    if (query.length < 2) return;
    
    fetch(`api/search_users.php?query=${query}&user_id=${currentUserId}`)
        .then(response => response.json())
        .then(users => {
            // In a real implementation, you would display these results
            // For now, we'll just log them
            console.log('Search results:', users);
        })
        .catch(error => {
            console.error('Error searching users:', error);
        });
}

function searchUsersForCompose() {
    const query = document.getElementById('recipient').value.trim();
    const resultsContainer = document.getElementById('search-results');
    
    if (query.length < 2) {
        resultsContainer.style.display = 'none';
        return;
    }
    
    fetch(`api/search_users.php?query=${query}&user_id=${currentUserId}`)
        .then(response => response.json())
        .then(users => {
            resultsContainer.innerHTML = '';
            
            if (users.length === 0) {
                resultsContainer.style.display = 'none';
                return;
            }
            
            users.forEach(user => {
                const resultItem = document.createElement('div');
                resultItem.className = 'search-result-item';
                resultItem.innerHTML = `
                    <div class="avatar">${getInitials(user.username)}</div>
                    <span>${user.username}</span>
                `;
                
                resultItem.addEventListener('click', () => {
                    document.getElementById('recipient').value = user.username;
                    resultsContainer.style.display = 'none';
                    document.getElementById('subject').focus();
                });
                
                resultsContainer.appendChild(resultItem);
            });
            
            resultsContainer.style.display = 'block';
        })
        .catch(error => {
            resultsContainer.style.display = 'none';
            console.error('Error searching users:', error);
        });
}

function showAlert(message, type = 'error') {
    const alert = document.createElement('div');
    alert.className = `alert ${type}`;
    alert.textContent = message;
    
    document.body.appendChild(alert);
    
    setTimeout(() => {
        alert.classList.add('show');
    }, 10);
    
    setTimeout(() => {
        alert.classList.remove('show');
        setTimeout(() => {
            alert.remove();
        }, 300);
    }, 3000);
}

