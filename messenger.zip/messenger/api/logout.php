<?php
require '../auth.php';

logout();
header('Location: login.html');
exit;
?>