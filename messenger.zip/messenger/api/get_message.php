<?php
require '../db.php';

header('Content-Type: application/json');

$messageId = $_GET['id'] ?? die(json_encode(['error' => 'Message ID required']));
$userId = $_GET['user_id'] ?? die(json_encode(['error' => 'User ID required']));

try {
    $stmt = $pdo->prepare("
        SELECT m.*, sender.username as sender, recipient.username as recipient 
        FROM messages m
        JOIN users sender ON m.sender_id = sender.id
        JOIN users recipient ON m.recipient_id = recipient.id
        WHERE m.id = ? AND (m.sender_id = ? OR m.recipient_id = ?)
    ");
    $stmt->execute([$messageId, $userId, $userId]);
    $message = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$message) {
        die(json_encode(['error' => 'Message not found or access denied']));
    }

    echo json_encode([
        'id' => $message['id'],
        'subject' => $message['subject'],
        'body' => $message['body'],
        'is_read' => (bool)$message['is_read'],
        'date' => date('M j, Y g:i a', strtotime($message['created_at'])),
        'sender' => $message['sender'],
        'recipient' => $message['recipient']
    ]);
    
} catch (PDOException $e) {
    die(json_encode(['error' => 'Database error: ' . $e->getMessage()]));
}
?>