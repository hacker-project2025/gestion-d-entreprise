<?php
require '../db.php';

header('Content-Type: application/json');

$userId = $_GET['user_id'] ?? die(json_encode(['error' => 'User ID required']));

try {
    // Get all users except current user
    $stmt = $pdo->prepare("SELECT id, username FROM users WHERE id != ? ORDER BY username");
    $stmt->execute([$userId]);
    $contacts = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode($contacts);
    
} catch (PDOException $e) {
    die(json_encode(['error' => 'Database error: ' . $e->getMessage()]));
}
?>