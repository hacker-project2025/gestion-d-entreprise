<?php
require '../db.php';

header('Content-Type: application/json');

$messageId = $_GET['id'] ?? die(json_encode(['success' => false, 'error' => 'Message ID required']));

try {
    $stmt = $pdo->prepare("UPDATE messages SET is_read = TRUE WHERE id = ?");
    $success = $stmt->execute([$messageId]);

    echo json_encode(['success' => $success]);
    
} catch (PDOException $e) {
    die(json_encode(['success' => false, 'error' => 'Database error: ' . $e->getMessage()]));
}
?>