<?php
require '../db.php';

header('Content-Type: application/json');

$query = $_GET['query'] ?? '';
$userId = $_GET['user_id'] ?? die(json_encode(['error' => 'User ID required']));

try {
    $stmt = $pdo->prepare("
        SELECT id, username 
        FROM users 
        WHERE id != ? AND username LIKE ? 
        ORDER BY username
        LIMIT 10
    ");
    $stmt->execute([$userId, "%$query%"]);
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode($users);
    
} catch (PDOException $e) {
    die(json_encode(['error' => 'Database error: ' . $e->getMessage()]));
}
?>