<?php
require '../db.php';

header('Content-Type: application/json');

$data = json_decode(file_get_contents('php://input'), true);

$senderId = $data['sender_id'] ?? die(json_encode(['success' => false, 'error' => 'Sender ID required']));
$recipientUsername = $data['recipient'] ?? die(json_encode(['success' => false, 'error' => 'Recipient required']));
$subject = $data['subject'] ?? '';
$body = $data['body'] ?? die(json_encode(['success' => false, 'error' => 'Message body required']));

try {
    // Get recipient ID
    $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ?");
    $stmt->execute([$recipientUsername]);
    $recipient = $stmt->fetch();

    if (!$recipient) {
        die(json_encode(['success' => false, 'error' => 'Recipient not found']));
    }

    // Insert message
    $stmt = $pdo->prepare("
        INSERT INTO messages (sender_id, recipient_id, subject, body) 
        VALUES (?, ?, ?, ?)
    ");
    $success = $stmt->execute([$senderId, $recipient['id'], $subject, $body]);

    echo json_encode([
        'success' => $success,
        'error' => $success ? null : 'Failed to send message'
    ]);
    
} catch (PDOException $e) {
    die(json_encode(['success' => false, 'error' => 'Database error: ' . $e->getMessage()]));
}
?>