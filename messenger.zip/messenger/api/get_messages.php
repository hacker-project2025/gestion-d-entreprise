<?php
require '../db.php';

header('Content-Type: application/json');

$folder = $_GET['folder'] ?? 'inbox';
$userId = $_GET['user_id'] ?? die(json_encode(['error' => 'User ID required']));

try {
    if ($folder === 'inbox') {
        $stmt = $pdo->prepare("
            SELECT m.id, m.subject, m.body, m.is_read, m.created_at, u.username as sender 
            FROM messages m 
            JOIN users u ON m.sender_id = u.id 
            WHERE m.recipient_id = ? 
            ORDER BY m.created_at DESC
        ");
    } else {
        $stmt = $pdo->prepare("
            SELECT m.id, m.subject, m.body, m.is_read, m.created_at, u.username as recipient 
            FROM messages m 
            JOIN users u ON m.recipient_id = u.id 
            WHERE m.sender_id = ? 
            ORDER BY m.created_at DESC
        ");
    }
    
    $stmt->execute([$userId]);
    $messages = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode(array_map(function($message) {
        return [
            'id' => $message['id'],
            'subject' => $message['subject'],
            'preview' => substr($message['body'], 0, 50) . (strlen($message['body']) > 50 ? '...' : ''),
            'is_read' => (bool)$message['is_read'],
            'date' => date('M j, Y g:i a', strtotime($message['created_at'])),
            'sender' => $message['sender'] ?? null,
            'recipient' => $message['recipient'] ?? null
        ];
    }, $messages));
    
} catch (PDOException $e) {
    die(json_encode(['error' => 'Database error: ' . $e->getMessage()]));
}
?>