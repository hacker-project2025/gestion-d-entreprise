<?php
require '../auth.php';

echo json_encode([
    'loggedIn' => isLoggedIn(),
    'username' => isLoggedIn() ? $_SESSION['username'] : null
]);
?>